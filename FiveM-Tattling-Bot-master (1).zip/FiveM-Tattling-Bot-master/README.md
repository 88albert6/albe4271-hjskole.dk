# FiveM Tattling Bot

This FivemM script will allow you to create a Discord Tattling Bot that reads FiveM messages and prints them in the Discord. It was created for FiveM a portuguese RP server => HargusRP (https://discord.gg/f6XPw72). 
If you want you can change it and adapt it to do whatever you want with it.

## Prerequisites

```
discord
FiveM
```

## Installing

For this to work you need to put the url of your Discord Webhook into the webhook_s.lua file 
Move the tattlingBot folder to your resources folder on your FiveM server and add ```start tattlingBot``` to your server.cfg file

## Contributing

- Feel free to contribute for this repository 

## Authors

* **Daniel Lages** - [daniellages](https://github.com/daniellages)
* **Luís Pinto** - [LiTO773](https://github.com/LiTO773)

## License

This project is licensed under the MIT License